<?php 

    ob_start();
    $db = new PDO("mysql:host=localhost;dbname=satirici;charset=utf8;","root","");

?>