<?php 

require_once 'config.php';


$column = strip_tags(trim($_POST['column']));
$value  = strip_tags(trim($_POST['value']));
$id     = strip_tags(trim($_POST['id']));

if(!$column || !$value || !$id){
    echo 'false';
}else{

    if($_POST['column'] == "eposta"){

        if(!filter_var($value,FILTER_VALIDATE_EMAIL)){
            echo 'false';
        }else{
            $up     = $db->prepare("UPDATE musteriler SET eposta =:u WHERE id=:id");
            $up->execute([
                ':u' => $value,
                ':id' =>$id
            ]);

            if($up){
                echo 'true';
            }else{
                echo 'false';
            }
        }
        
    }else{

        $up     = $db->prepare("UPDATE musteriler SET $column =:u WHERE id=:id");
        $up->execute([
            ':u' => $value,
            ':id' =>$id
        ]);

        if($up){
            echo 'true';
        }else{
            echo 'false';
        }

    }

}

?>