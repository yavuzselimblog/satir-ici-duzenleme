<?php 
require_once 'config.php';
?>
<html>
<head>
    <title>satır içi düzenleme</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
</head>
<body>

    <?php 
        $query = $db->prepare("SELECT * FROM musteriler");
        $query->execute();
        if($query->rowCount()){
            ?>  

            <div class="table-responsive">
                <table class="table table-hover table-bordered">
                    <thead>
                        <tr class="bg-primary">
                        <th>İSİM</th>
                        <th>EPOSTA</th>
                        <th>ŞEHİR</th>
                         </th>
                    </thead>
                    <tbody>
                        <?php foreach($query as $row){ ?>
                        <tr>
                            <td contenteditable="true" onfocus="changeBackground(this);" onblur="saveData(this, '<?php echo $row['id'];?>','isim')"><?php echo $row['isim'];?></td>
                            <td contenteditable="true" onfocus="changeBackground(this);" onblur="saveData(this, '<?php echo $row['id'];?>','eposta')"><?php echo $row['eposta'];?></td>
                            <td contenteditable="true" onfocus="changeBackground(this);" onblur="saveData(this, '<?php echo $row['id'];?>','sehir')"><?php echo $row['sehir'];?></td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>

            
            <?php 
        }else{
            echo 'veri yok2';
        }
    ?>


<script>

    function changeBackground(obj){
        $(obj).removeClass('bg-success');
        $(obj).addClass('bg-danger');
    }

    function saveData(obj,id,column){
        var customer = {
            id     : id,
            column : column,
            value  : obj.innerHTML
        }
        $.ajax({
            type : "POST",
            url  : "savedata.php",
            data : customer,
            dataType : 'json',
            success : function(data){

                if(data){
                    $(obj).removeClass('bg-danger');
                    $(obj).addClass('bg-success');
                }else{
                    alert("Hata oluştu");
                }

            }
        })
    }

</script>


</body>
</html>